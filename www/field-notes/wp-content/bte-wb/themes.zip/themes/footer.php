<?php function_exists('apture_script') && apture_script(); ?>
<?php
/**
 *	@package WordPress
 *	@subpackage Grid_Focus
 */
?>
	<?php include (TEMPLATEPATH . '/footer.strip.php'); ?>
	<div id="footer" class="fix">
		<p class="right">Based on Grid Focus</p>
	
	</div>
</div>
<?php wp_footer(); ?></div>

<div id="footer2">
	<?php
require_once(dirname(__FILE__)."/../../../../scripts/navigation.php");
$nav = new Navigation();
  $nav->footerUtilmenu(); ?>
	
</div>
</body>
</html>