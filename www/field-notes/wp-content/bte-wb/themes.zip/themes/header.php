<?php
#echo('<!--'.file_get_contents(dirname(__FILE__)."/../../../../scripts/navigation.php").'-->');
require_once(dirname(__FILE__)."/../../../../scripts/navigation.php");
$nav = new Navigation();
$userId = $nav->userid;
$utype = $nav->usertypeID;
?>
<?php
/**
 *	@package WordPress
 *	@subpackage Grid_Focus
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php if (function_exists('is_tag') && is_tag()) { echo 'Posts tagged &quot;'.$tag.'&quot; - '; } elseif (is_archive()) { wp_title(''); echo ' Archive - '; } elseif (is_search()) { echo 'Search for &quot;'.wp_specialchars($s).'&quot; - '; } elseif (!(is_404()) && (is_single()) || (is_page())) { wp_title(''); echo ' - '; } elseif (is_404()) { echo 'Not Found - '; } bloginfo('name'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<link rel="stylesheet" href="/lo2/libraries/lo2_navigation.css" type="text/css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<script src="<?php bloginfo('template_url') ?>/js/jquery-1.2.6.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="<?php bloginfo('template_url') ?>/js/functions.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" src="http://localorb.it/MAGstore/js/lo/localOrbit.js"></script>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<?php wp_head(); ?>
</head>
<body>
<div id="wrapper">
	
	<div id="masthead" class="fix">
	<div class="header">
<a href="../" onclick="addParams(this)"><img src="/img/common/logo.gif" alt="Local Orbit"  /></a>
   <div id="topNavBar">
<?php 
#$nav->topUtilmenu(); 
?>
		<? if( intval($_SESSION['ACCOUNT_TYPE']) == 0 ){?>
			<a href="/lo2/registration/form" class="nav_image" id="signup" title="signup for local orbit"></a>
			<a href="/lo2/authentication/login" class="nav_image" id="login" title="log in to local orbit"></a>
			
			<div style="height:1px; width: 350px; background-color:#CB9E39; clear:both; margin-left:40px;"></div> 
			
			<a href="/lo2/misc/how-it-works" class="nav_image" id="aboutus" title="about local orbit"></a>
			<a href="/lo2/misc/contact-us" class="nav_image" id="contactus" title="contact local orbit"></a>
			<a href="/lo2/" class="nav_image" id="home" title="home"></a>
			
			
		
		<? } else { ?>
		
			<a href="/lo2/authentication/logout" class="nav_image" id="logout" title="logout of local orbit"></a>
			<a href="/MAGstore/index.php/checkout/cart/" class="nav_image"id="cart" title="view your shopping cart	"></a>
			<a href="/lo2/dashboard/view" class="nav_image" id="dashboard" title="view your dashboard	"></a>	
			
			<div style="height:1px; width: 350px; background-color:#CB9E39; clear:both; margin-left:40px;"></div> 
			<a href="/lo2/misc/help" class="nav_image" id="help" title="help using local orbit"></a>
			<a href="/lo2/misc/contact-us" class="nav_image" id="contactus" title="contact local orbit"></a>
			<a href="/" class="nav_image" id="home" title="home"></a>
			
			
		<? } ?>
    </div>
 <div  id="navigation">
	<? if( intval($_SESSION['ACCOUNT_TYPE']) == 0 ){?>
	<a href="/lo2/misc/buy-local" class="mainnav_image" id="buylocal" title="buy local"></a>
	<a href="/lo2/misc/sell-local" class="mainnav_image" id="selllocal" title="sell local"></a> 
	<?}else{?>
	<a href="/MAGstore/" class="mainnav_image" id="buylocal" title="buy local"></a>
	<a href="/lo2/sellers/view" class="mainnav_image" id="oursellers" title="sell local"></a> 
	<?}?>
	<a href="/field-notes/" class="mainnav_image" id="knowlocal_o" title="know local"></a> 
<?php
 #$nav->globalmenu(); 
 
 ?>
	</div>


		
		<h1><a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div id="blogLead">
			
			
		</div>
	</div>
	
	<?php include (TEMPLATEPATH . '/navigation.strip.php'); ?>
