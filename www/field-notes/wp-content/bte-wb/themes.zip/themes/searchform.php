<?php
/**
 *	@package WordPress
 *	@subpackage Grid_Focus
 */
?>
<?php { /* search fields with separate ids in both navigation.strip.php and footer.strip.php ?>
<div>
	<form method="get" id="searchForm" action="<?php bloginfo('home'); ?>/">
	<span><input type="text" value="Search the archives..." onfocus="if (this.value == 'Search the archives...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search the archives...';}" name="s" id="s" /></span>
	</form>
</div>
<?php */ } ?>