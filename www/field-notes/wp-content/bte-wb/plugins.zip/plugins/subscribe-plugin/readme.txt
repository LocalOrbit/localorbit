Ԫ�=== Subscribe Widget ===
Contributors: K��stas Mind��iulis
Donate link: http://www.pclastnews.com/subscribe-widget.html
Tags: Subscribe, widget, rss, twitter, reader, sidebar, feed, feedburner, rss reader
Requires at least: 2.3
Tested up to: 2.7.1
Stable tag: 1.1.5

Sidebar widget to easy customize and display your subscribers buttons. All settings are available from Sidebar Widget Admin.


== Description ==
Important: Before plugin install make sure that folders can be created by wordpress in your blog directory (root directory of the blog). Or you can create it yourself. Folders name should be: subscribe-widget; permissions: 0777.

Subscribe-Widget is a free wordpress plugin, which was designed to be used by all bloggers wishing to inform readers about specific information, in a fast and reliable way. This plug-in will create: rss2, comments rss, twitter and feedburner icons on your blog sidebar. These icons will in turn lead readers to your rss, twitter, feedburner and comments rss, accordingly,  readers will tehn be able to find the latest news on your blog. If you want you can disable these icons one by one and only leave those which are needed. To enable the twitter and feedburner icons, one should have acounts on www.twitter.com and www.feedburner.com, as the plugin creates links to these blog accounts. 

Subscribe-Widget has been dessogned to be very practical, as the blog admin allows for one to be able to choose your icons��� width and height, allows for one to be able to write a title (which will appear above the icons), one will also be able to choose hwo to align the icons (left, center, right), as well as beign able to disable these icons one by one. Should you be struggling to find the right icon, you can also upload one by yourself. Go to: plugins directory /wp-content/plugins/subscribe-widget/images/. New uploaded icons may vary in size, as the Subscribe-Widget plugin will resize the icon to the needed width or height, however images should be no smaller then 50��50 pixels. So, by choosing to use this plug-in, one can choose how to display your icons, as it is all up to you, the blogger.

Now you can use subscribe icons anywhere on the theme. Only thing is, you should use this code: `<?php if( function_exists(sw_displayOnTheTheme()) ){ sw_displayOnTheTheme(); } ?>`. Put it on the needed theme file, check the checkbox on "Show 'Subscribe Icons' on the theme" and it will show the images on the theme, but will disable images on the widget. In some cases, there should be some styling done on the theme, to show those images correctly; because the themes are different, and styling can't be made for all of them.

Important to note: Images will be resized, firstly by width and then by height. If images width will be smaller then selected, then image will be not resized. The same applies to the image height.

Plugins idea author: [http://www.computersafetytip.com](http://www.computersafetytip.com)

== Installation ==
1. Download `subscribe-widget` plugin from www.pclastnews.com and unzip it.
2. Upload the folder `subscribe-widget` to your WP plugin folder `/wp-content/plugins/` directory
3. Activate the `Subscribe widget` plugin through the `Plugins` menu in WordPress admin
4. Go to `Appearance`: `Widgets`, `Add` widget `Subscribe widget` and `Save Changes`
5. After the page reloads on the widget `Subscribe widget` at right, click `Edit`, set all the information and select images.
6. Click `Done` and `Save Changes` to the sidebar from the button bellow
7. You are ready, check the subscribers buttons in the sidebar of your favorite WordPress blog


== Frequently Asked Questions == 

== Screenshots ==

1. Administration interface in WordPress 2.

2. Administration interface in WordPress 2.

3. Plugin interface in WordPress 2.

== Licence ==

Good news, this plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But if you enjoy this plugin, you can thank me and leave a [small donation](http://www.pclastnews.com/subscribe-widget.html) for the time I���ve spent writing and supporting this plugin. And I really don���t want to know how many hours of my life this plugin has already eaten ;)


Good luck!

P.S. Sorry for my bad english. :)





