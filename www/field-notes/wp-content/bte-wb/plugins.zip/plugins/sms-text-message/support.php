<?php 
function mrt_sms_support_page(){ ?>

   <div class=wrap>
      <h2><?php _e('SMS Text Message Support') ?></h2>
      
      <div style="height:299px">
         Under Construction...<br /><br />
      <!--   <ul>
            <li><a href='' target="_blank">Changelog</a></li>
            <li><a href='' target="_blank">Documentation</a></li>
         </ul>-->
         <br /><br /><strong>Backup early, backup often!</strong><br /><br /><br /><br /><br />
         <em>For comments, suggestions, bug reporting, etc please <a href="http://semperfiwebdesign.com/contact/">click here</a>.</em>
      </div>
   
      Plugin by <a href="http://semperfiwebdesign.com/" title="Semper Fi Web Design">Semper Fi Web Design</a>
   </div>
<?php } ?>
