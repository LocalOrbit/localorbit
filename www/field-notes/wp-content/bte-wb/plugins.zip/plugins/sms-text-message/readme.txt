=== Plugin Name ===
Contributors: hallsofmontezuma
Donate link:https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=mrtorbert%40gmail%2ecom&item_name=Support%20WordPress%20Security%20Scan%20Plugin&no_shipping=0&no_note=1&tax=0&currency_code=USD&lc=US&bn=PP%2dDonationsBF&charset=UTF%2d8
Tags: admin, administration, authentication, database, dashboard, post, notification, email, plugin, posts, sms, text, text message, text messaging, notify, widget, comments, sidebar, images, google, links, Formatting, Ajax, rss
plugins, private, tracking, wordpress
Requires at least: 2.0
Tested up to: 2.8
Stable tag: trunk

Allows a reader to submit their phone number through a sidebar widget.  The
blog owner then can periodically send alerts, updates, etc via SMS to everyone
at once.

== Description ==

Allows a reader to submit their phone number through a sidebar widget.  The
blog owner then can periodically send alerts, updates, etc via SMS to everyone
at once.

**Features**<br />
-includes built-in widget<br />
-easy, simple administrative management interface<br />
-support for all the major wireless carriers<br />

**Future Releases**<br />
*email me or start a thread with features you would like to see<br />

[Changelog](http://semperfiwebdesign.com/documentation/sms-text-message/ "SMS Text Message Changelog") COMING SOON<br />
[Documentation](http://semperfiwebdesign.com/category/documentation/sms-text-message/ "SMS Text Message
Documentation") COMING SOON<br />

== Installation ==

1. Create backup.
2. Upload the zip file to the `/wp-content/plugins/` directory
3. Unzip.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. Drag the widget over to your active widgets.
6. Enjoy.

Please let me know any bugs, improvements, comments, suggestions.

== Frequently Asked Questions ==

= Do the phone numbers need to be entered in a certain format? =

No.  (123) 456-7890 is the same as 123-456-7890 is the same as 1234567890 is
the same as 123 456 7890 ad infinitum

== Screenshots ==

1. first one desc
2. next desc


== SMS Text Message ==

Text message updates:

1. Allows widget for people to add their phone number
1. Blog owner can send periodic SMS updates


Join the BETA testers group if:

* you have experience as a software tester
* you have no experience as a software tester
* you have a WordPress installation dedicated for testing
* you have a general enthusiasm for WordPress use and/or development


Visit our homepage at [Semper Fi Web Design](http://semperfiwebdesign.com/ "Raleigh Web Design") or our plugin page at [Semper Fi Plugins][sf plugins].
We look forward to hearing your comments and suggestions.

[sf plugins]: http://semperfiwebdesign.com/plugins/
            "Raleigh Web Design"

> SMS Text Message for *2.3, 2.5*. Although if you're using lower
> than 2.3 you should go ahead and install it because of **security**.

`<?php code(); // backticks ?>`
