<?php
/**
 * All pages are wrapped in class, this is the base class for all pages.
 *
 * @category   Wordpress
 * @package    Umapper_Pages
 * @copyright  2008 Advanced Flash Components
 * @version    1.0.0
 */

/**
 * @category   Wordpress
 * @package    Umapper_Pages
 * @copyright  2008 Advanced Flash Components
 * @version    Release: 1.0.0
 * @author     Victor Farazdagi <victor@afcomponents.com>
 */ 
class Umapper_Pages
{}