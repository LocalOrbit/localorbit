<?php
/**
 * Umapper_Pages_MediaMapMeta
 */
require_once 'Umapper/Pages/MediaMapMeta.php';

/**
 * Umapper_Pages_MediaMapEditor
 */
require_once 'Umapper/Pages/MediaMapEditor.php';

/**
 * Umapper_Pages_MediaMaps
 */
require_once 'Umapper/Pages/MediaMaps.php';