=== Dashboard Lite ===
Contributors: mwdmeyer
Tags: admin, dashboard
Requires at least: 2.2.0
Tested up to: 2.2
Stable tag: 0.3

Removes incoming links, dev news and planet news off the dashboard. 

== Description ==

Removes incoming links, dev news and planet news off the dashboard. 

== Installation ==

1. Download
1. Unzip (zip contains dashboard-lite.php)
1. Upload to wp-content/plugins
1. Activate within Wordpress Admin Panel

== Frequently Asked Questions ==



== Change Log ==

KEY  
* = Bug fix  
+ = Added feature/function  
- = Something changed (only if not a bug fix)  

Change Log Start

Note: Release Date is DD/MM/YYYY :)

0.3 (Released 21/04/2008)

-Changed Plugin URI

0.2 (Released 15/06/2007)

+Added Security

0.1 (Released 17/05/2007)

+Public release
