Free WordPress Themes from 1800blogger.com
http://1800blogger.com/free-wordpress-themes/

INSTALL: 
1. Unpack this archive in your wp-content/themes/ directory.
2. Go to Admin WordPress and select presentation.
3. Select theme.


Extended licenses for stock photos have been purchased from iStockPhoto.com

