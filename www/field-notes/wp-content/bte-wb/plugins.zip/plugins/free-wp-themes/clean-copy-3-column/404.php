<?php get_header(); ?>



<!--create your own error 404 page-->
<!--include sidebar-->

<?php include(TEMPLATEPATH."/sidebar.php");?>

<!--include sidebar2-->

<?php include(TEMPLATEPATH."/sidebar2.php");?>

<div id="content">



<h2>Whoops! That Page Isn't Here </h2>

            <p>&nbsp;</p>

<div class="postspace2">

	</div>			



</div>

<!--include footer-->

<?php get_footer(); ?>