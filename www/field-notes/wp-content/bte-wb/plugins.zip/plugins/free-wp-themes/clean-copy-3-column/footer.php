<div id="footer">

<!--footer.php-->

<strong><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></strong> <br /><br />

 Clean Copy by <a href="http://happyjoe.com" title="Blog Hosting">Happy Joe</a> | Made free by <a href="http://www.michelfortin.com/">Copywriter Michel Fortin</a>

<!--necessary-->

<?php wp_footer(); ?>

</div>

</div>

</body>

</html>

