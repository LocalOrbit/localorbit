</div>

<div id="footer">

		Copyright &copy; 2008 <a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a>  | All rights reserved<br />
Theme by <a href="http://www.1800blogger.com/" title="The Blog Company" >1800blogger</a> and <a href="http://ithemes.com/" title="Premium WordPress Themes" >iThemes</a>




                 <!--necessary-->
		<?php wp_footer(); ?>
		</div>



</body>
</html>
