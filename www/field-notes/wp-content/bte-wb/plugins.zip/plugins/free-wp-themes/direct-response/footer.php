</div>

<div id="footer">

<!--footer.php-->
		<strong><?php bloginfo('name'); ?></strong> | Design by <a href="http://happyjoe.com" title="Blog Hosting">Happy Joe</a> in collaboration with <a href="http://www.rayedwards.com">Copywriter Ray Edwards</a>

<br /><br />

                 <!--necessary-->
		<?php wp_footer(); ?>
		</div>



</body>
</html>
