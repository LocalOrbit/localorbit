=== Google Reader Subscription List ===
Contributors: broderboy
Tags: google reader, rss
Requires at least: 2.3
Tested up to: 2.8
Stable tag: trunk

This plugin will display the feeds that you subscribe to in Google Reader on a wordpress page

== Description ==

This plugin will display the feeds that you subscribe to in Google Reader on a wordpress page

== Installation ==

1. Install and activate the Zend Framework plugin http://wordpress.org/extend/plugins/zend-framework/
2. Upload google-reader-subscription-list.php to the /wp-content/plugins/ directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Fill out user credentials on the options page
5. Create a blank page with a custom field "show-google-reader-sub-list" with the value true

